#include <stdio.h>

int main(int argc, const char *argv[])
{
	int aa = 0xaa;
	aa = ~aa;
	printf("aa = %#x\n",aa);
	return 0;
}
