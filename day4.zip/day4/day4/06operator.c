#include <stdio.h>

int main(int argc, const char *argv[])
{
	int p,j=5;
	//    6     7     8    9 = 30
	//p = (++j)+(++j)+(++j)+(++j);

	//p = (++j)+(++j); //14
	p = (++j)+(++j)+(++j);

	printf("p = %d\n",p);
	return 0;
}
