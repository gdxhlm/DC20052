#include <stdio.h>

int main(int argc, const char *argv[])
{
	int a = 5,c;
	c = ++a;
	printf("c = %d\n",c);
	c = a++;
	printf("c = %d\n",c);
	printf("a = %d\n",a);

	return 0;
}
