#include <stdio.h>

#define MAX(a,b)  \
	({int max;if(a>b)max=a;else max=b;max;})

int main(int argc, const char *argv[])
{
	int a=10,b=50;

	printf("MAX = %d\n",\
			MAX(a,b));
	return 0;
}
