#include <stdio.h>

int main(int argc, const char *argv[])
{
	int a = 0;
	int b = 100;

	printf("!a = %d\n",!a); //1
	printf("!b = %d\n",!b); //0
	return 0;
}
