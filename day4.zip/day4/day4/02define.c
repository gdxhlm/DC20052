#include <stdio.h>

#define ENOENT  2 
#define S(a)    #a


int main(int argc, const char *argv[])
{
	printf("S(12) = %s\n",S(12));
	printf("%d\n",ENOENT);
	printf("%s\n",S(ENOENT));
	return 0;
}
