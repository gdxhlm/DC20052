#include <stdio.h>
#define TT  123
#define NAME(m,n) m##n

int main(int argc, const char *argv[])
{
	int hello=456;

	printf("NAME = %d\n",NAME(h,ello));
	printf("NAME = %d\n",NAME(he,llo));
	printf("NAME = %d\n",NAME(hell,o));
	printf("NAME = %d\n",NAME(T,T));

	return 0;
}
