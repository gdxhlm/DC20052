#include <stdio.h>
#define N 10
#define M N+5

int main(int argc, const char *argv[])
{
	printf("2*M = %d\n",2*M); 
	//2*10+5   结果是25
	printf("M*M = %d\n",M*M);
	//10+5*10+5 结果是65

	return 0;
}
