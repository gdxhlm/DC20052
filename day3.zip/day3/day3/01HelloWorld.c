//#include <stdio.h>
#include "stdio.h"
//包含printf的头文件，stdio.h就是头文件
//<> stdio.h在系统的头文件的目录下usr/include
//"" 先在系统的头文件目录中找头文件，如果没招到在当前目录下包含头文件

//c语言的入口函数
int main(int argc, const char *argv[])
{
	//打印函数   \n 换行 ;表示一句话执行结束了
	printf("hello world.\n");	
	printf("hello DC20052 everybody\n");	

	return 0;
	//返回程序执行的状态，0表示执行成功了，负数表示执行失败了
}
