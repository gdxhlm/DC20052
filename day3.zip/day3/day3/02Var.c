#include <stdio.h>

#define M 10

int main(int argc, const char *argv[])
{
	char a = 65;
	int b = 10;
	int c = 0b11010010;
	int d = 0xff3a80c0;
	int e = 0775;
	float v = 3.1415;
	long t = 1231242;
	long long w = 123123123;
	double y = 1231.123;
	long double u = 11.2233;

	printf("a = %c\n",a); //%c打印的是字符类型
	printf("a = %d\n",a); //%c打印的是字符类型
	printf("b = %d\n",b); //%d打印的是整型数
	printf("c = %d\n",c); //%d打印的是整型数
	printf("d = %#x\n",d); //%x打印的是十六进制数，
						   //#自动补充前缀
	printf("e = %#o\n",e); //%o打印八进制
	printf("v = %f\n",v);  //%f小数
	printf("v = %.2f\n",v);  //%f小数
	printf("v = %g\n",v);  //%g小数
	printf("v = %e\n",v);  //%e小数
	printf("t = %ld\n",t);
	printf("w = %lld\n",w);
	printf("y = %e\n",y);  //%e小数
	printf("u = %Lf\n",u);  //%f小数
	printf("M = %d\n",M);
	return 0;
}
