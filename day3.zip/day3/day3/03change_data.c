#include <stdio.h>

int main(int argc, const char *argv[])
{
	int a = 5,b = 10,c;
#if 0
	c = a;
	a = b;
	b = c;
	printf("a = %d,b = %d\n",a,b);
#else
	a = a + b;
	b = a - b;
	a = a - b;
	printf("a = %d,b = %d\n",a,b);
#endif
	return 0;
}
