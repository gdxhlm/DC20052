#include <stdio.h>

int main(int argc, const char *argv[])
{
	char a = 128;
	char b = 129;
	char c = 130;
	printf("a = %d\n",a);
	printf("b = %d\n",b);
	printf("c = %d\n",c);

	return 0;
}
